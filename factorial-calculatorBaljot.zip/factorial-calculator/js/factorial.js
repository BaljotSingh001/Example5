document.addEventListener('DOMContentLoaded', () => {
    const darkModeButton = document.getElementById('darkMode');
    const lightModeButton = document.getElementById('lightMode');
    const calculateButton = document.getElementById('calculateButton');
    const resultScreen = document.getElementById('resultScreen');
    const factorialInput = document.getElementById('factorialInput');

    darkModeButton.addEventListener('click', () => {
        document.body.classList.add('bg-dark', 'text-light');
        document.body.classList.remove('bg-light', 'text-dark');
    });

    lightModeButton.addEventListener('click', () => {
        document.body.classList.add('bg-light', 'text-dark');
        document.body.classList.remove('bg-dark', 'text-light');
    });

    calculateButton.addEventListener('click', () => {
        const input = parseInt(factorialInput.value);
        if (isNaN(input) || input < 0) {
            resultScreen.textContent = 'Please enter a non-negative integer.';
            return;
        }
        let factorial = 1;
        for (let i = 1; i <= input; i++) {
            factorial *= i;
        }
        resultScreen.textContent = `${input}! = ${factorial}`;
    });
});
